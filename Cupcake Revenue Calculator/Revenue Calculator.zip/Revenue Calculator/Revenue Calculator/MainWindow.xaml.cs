﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using Microsoft.Win32;

namespace Revenue_Calculator
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        //lists of how many of each cupcake was sold each day
        List<int> BasicCakesLst = new List<int>();
        List<int> DeluxeCakesLst = new List<int>();
        List<int> TotalCakesLst = new List<int>();

        //takes string of text from file, splits on newline, returns as list of ints without header line
        public static List<int> stringSplit(string text) {

            string[] lines = text.Split('\n');
            List<string> stringlist = lines.ToList();
            stringlist.RemoveAt(0);
            List<int> intList = stringlist.ConvertAll(int.Parse);

            return intList;
        }

        //takes list of daily totals, returns list with 7-day totals
        public static List<int> Weekly(List<int> intList, char c)
        {
            List<int> sums = new List<int>();
            List<int> returnList = new List<int>();
            int weeklyReturn;
            int counter = 0;
            int prod = 0;
            intList.Reverse();

            switch (c)
            {
                case 'b':
                    //multiply each value by 5 (the basic rate)
                    foreach (int i in intList)
                    {
                        prod = i * 5;
                        sums.Add(prod);
                    }
                    break;

                case 'd':
                    //multiply each value by 6 (the deluxe rate)
                    foreach (int i in intList)
                    {
                        prod = i * 6;
                        sums.Add(prod);
                    }
                    break;
            }

            //sum each 7 entries to find weekly total
            while (counter < intList.Count)
            {
                //sum 7 entiries, store in var, put that in list for return
                weeklyReturn = sums.Take(7).Sum();
                returnList.Add(weeklyReturn);

                //shorten lists and progress counter
                intList.RemoveRange(0, 7);
                sums.RemoveRange(0, 7);
                counter++;

            }

            return returnList;
        }

        //clone from Weekly, returns 30-day totals
        public static List<int> Monthly(List<int> intList, char c)
        {
            List<int> sums = new List<int>();
            List<int> returnList = new List<int>();
            int monthlyReturn;
            int counter = 0;
            int prod = 0;
            intList.Reverse();

            switch (c)
            {
                case 'b':
                    //multiply each value by 5 (the basic rate)
                    foreach (int i in intList)
                    {
                        prod = i * 5;
                        sums.Add(prod);
                    }
                    break;

                case 'd':
                    //multiply each value by 6 (the deluxe rate)
                    foreach (int i in intList)
                    {
                        prod = i * 6;
                        sums.Add(prod);
                    }
                    break;
            }

            //sum each 30 entries to find monthly total
            
            while (counter < intList.Count)
            {
                //sum 30 entiries, store in var, put that in list for return
                monthlyReturn = sums.Take(30).Sum();
                returnList.Add(monthlyReturn);

                //shorten lists and progress counter
                intList.RemoveRange(0, 30);
                sums.RemoveRange(0, 30);
                counter++;
            }

            return returnList;
        }

        //clone from Weekly, returns 365-day totals
        public static List<int> Yearly(List<int> intList, char c)
        {
            List<int> sums = new List<int>();
            List<int> returnList = new List<int>();
            int yearlyReturn;
            int counter = 0;
            int prod = 0;
            intList.Reverse();

            switch (c)
            {
                case 'b':
                    //multiply each value by 5 (the basic rate)
                    foreach (int i in intList)
                    {
                        prod = i * 5;
                        sums.Add(prod);
                    }
                    break;

                case 'd':
                    //multiply each value by 6 (the deluxe rate)
                    foreach (int i in intList)
                    {
                        prod = i * 6;
                        sums.Add(prod);
                    }
                    break;
            }

            //sum each 7 entries to find weekly total
            while (counter < intList.Count)
            {
                //sum 7 entiries, store in var, put that in list for return
                yearlyReturn = sums.Take(365).Sum();
                returnList.Add(yearlyReturn);

                //shorten lists and progress counter
                intList.RemoveRange(0, 365);
                sums.RemoveRange(0, 365);
                counter++;
            }

            return returnList;
        }

        //formats list of ints into string for display
        public string displayMembers(List<int> Sums, char c) {
            int index = Sums.Count();
            var text = string.Empty;

            switch (c)
            {
                case 'w':
                    foreach (int s in Sums)
                    {
                        text += "Week " + index + ": $" + s.ToString() + "\r\n";
                        index--;
                    }
                    break;

                case 'm':
                    foreach (int s in Sums)
                    {
                        text += "Month " + index + ": $" + s.ToString() + "\r\n";
                        index--;
                    }
                    break;

                case 'y':
                    foreach (int s in Sums)
                    {
                        text += "Year " + index + ": $" + s.ToString() + "\r\n";
                        index--;
                    }
                    break;
            }
            return text;
        }

        //Click Events

        private void FileBtn_Click(object sender, RoutedEventArgs e)
        {
            BasicTxt.IsReadOnly = true;
            DeluxeTxt.IsReadOnly = true;
            OpenFileDialog ofd = new OpenFileDialog();
            if (ofd.ShowDialog() == true)
            {
                string file = File.ReadAllText(ofd.FileName);

                string[] lines = file.Split('\n');
                if (lines[0].Contains("Basic"))
                {
                    BasicTxt.Text = String.Join("\n", lines);
                    BasicCakesLst = stringSplit(BasicTxt.Text);
                }
                if (lines[0].Contains("Delux"))
                {
                    DeluxeTxt.Text = String.Join("\n", lines);
                    DeluxeCakesLst = stringSplit(DeluxeTxt.Text);
                }

            }

        }

        private void WeeklyBtn_Click(object sender, RoutedEventArgs e)
        {
            List<int> basicTotals = Weekly(BasicCakesLst, 'b');
            List<int> deluxTotals = Weekly(DeluxeCakesLst, 'd');
            if (basicTotals.Count > 0)
            {
                WeeklyBasicTxt.Text = displayMembers(basicTotals, 'w');
            }
            if (deluxTotals.Count > 0)
            {
                WeeklyDeluxeTxt.Text = displayMembers(deluxTotals, 'w');
            }
        }

        private void MonthlyBtn_Click(object sender, RoutedEventArgs e)
        {
            List<int> basicTotals = Monthly(BasicCakesLst, 'b');
            List<int> deluxTotals = Monthly(DeluxeCakesLst, 'd');
            if (basicTotals.Count > 0)
            {
                MonthlyBasicTxt.Text = displayMembers(basicTotals, 'm');
            }
            if (deluxTotals.Count > 0)
            {
                MonthlyDeluxeTxt.Text = displayMembers(deluxTotals, 'm');
            }
        }

        private void YearlyBtn_Click(object sender, RoutedEventArgs e)
        {
            List<int> basicTotals = Yearly(BasicCakesLst, 'b');
            List<int> deluxTotals = Yearly(DeluxeCakesLst, 'd');
            if (basicTotals.Count > 0)
            {
                YearlyBasicTxt.Text = displayMembers(basicTotals, 'y');
            }
            if (deluxTotals.Count > 0)
            {
                YearlyDeluxeTxt.Text = displayMembers(deluxTotals, 'y');
            }
        }
    }
}
